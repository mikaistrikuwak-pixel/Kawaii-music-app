package com.kawaii.music;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.JavascriptInterface;

/** Dipanggil dari HTML lewat window.KMNative. */
final class NativeBridge {
    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String lastCoverStr = "";
    private Bitmap lastCover;

    NativeBridge(Context c) {
        ctx = c.getApplicationContext();
    }

    private Bitmap decode(String cover) {
        if (cover == null || cover.isEmpty()) return null;
        if (cover.equals(lastCoverStr)) return lastCover;
        Bitmap b = null;
        try {
            int i = cover.indexOf("base64,");
            if (cover.startsWith("data:") && i > 0) {
                byte[] raw = Base64.decode(cover.substring(i + 7), Base64.DEFAULT);
                b = BitmapFactory.decodeByteArray(raw, 0, raw.length);
            }
        } catch (Throwable ignored) {
        }
        lastCoverStr = cover;
        lastCover = b;
        return b;
    }

    @JavascriptInterface
    public void update(String title, String artist, String cover, boolean playing, long posMs, long durMs) {
        final MediaService.State s = new MediaService.State(
                title == null ? "" : title,
                artist == null ? "" : artist,
                decode(cover), playing, Math.max(0, posMs), Math.max(0, durMs));
        main.post(new Runnable() {
            @Override public void run() {
                MediaService.push(ctx, s);
            }
        });
    }

    @JavascriptInterface
    public void clear() {
        main.post(new Runnable() {
            @Override public void run() {
                MediaService.shutdown();
            }
        });
    }
}
