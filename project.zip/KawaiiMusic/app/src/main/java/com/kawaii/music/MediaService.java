package com.kawaii.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/**
 * Notifikasi musik: cover, judul, artis, seekbar, prev/play/next, -10 detik, dan tombol X.
 * Notifikasi bersifat "ongoing" (tidak bisa digeser) - hanya hilang lewat tombol X.
 */
public class MediaService extends Service {

    /**
     * Layar kontrol media Android 13+ hanya punya 5 slot: [kustom] [prev] [play] [next] [kustom].
     * false -> slot kanan = tombol X (tutup).   true -> slot kanan = +10 detik (X tidak tampil).
     */
    static final boolean RIGHT_SLOT_IS_FWD10 = false;

    static final String CH_ID = "kawaii_music_playback";
    static final int NOTIF_ID = 1001;

    static final String A_INIT = "kw.init";
    static final String A_PLAY = "kw.play";
    static final String A_PAUSE = "kw.pause";
    static final String A_NEXT = "kw.next";
    static final String A_PREV = "kw.prev";
    static final String A_BACK = "kw.back10";
    static final String A_FWD = "kw.fwd10";
    static final String A_CLOSE = "kw.close";

    static final class State {
        final String title, artist;
        final Bitmap cover;
        final boolean playing;
        final long pos, dur;

        State(String title, String artist, Bitmap cover, boolean playing, long pos, long dur) {
            this.title = title;
            this.artist = artist;
            this.cover = cover;
            this.playing = playing;
            this.pos = pos;
            this.dur = dur;
        }
    }

    private static MediaService inst;
    private static State pending;
    private static boolean dismissed;

    // ---------- API statis (selalu dipanggil dari main thread) ----------

    static void push(Context c, State s) {
        if (dismissed) {
            if (!s.playing) return;   // setelah ditutup (X), abaikan sampai lagu diputar lagi
            dismissed = false;
        }
        if (inst != null) {
            inst.apply(s);
            return;
        }
        pending = s;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, MediaService.class).setAction(A_INIT));
        } catch (Throwable t) {
            pending = null;
        }
    }

    static void shutdown() {
        pending = null;
        if (inst != null) inst.closeNotif(false);
    }

    // ---------- instance ----------

    private MediaSessionCompat session;
    private NotificationManager nm;
    private PowerManager.WakeLock wl;
    private boolean fg;

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "Pemutar musik", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        session = new MediaSessionCompat(this, "KawaiiMusic");
        session.setCallback(new MediaSessionCompat.Callback() {
            @Override public void onPlay() { act(A_PLAY); }
            @Override public void onPause() { act(A_PAUSE); }
            @Override public void onSkipToNext() { act(A_NEXT); }
            @Override public void onSkipToPrevious() { act(A_PREV); }
            @Override public void onRewind() { act(A_BACK); }
            @Override public void onFastForward() { act(A_FWD); }
            @Override public void onStop() { act(A_CLOSE); }
            @Override public void onSeekTo(long pos) {
                Bridge.js("window.__nm&&window.__nm('seek'," + (pos / 1000.0) + ")");
            }
            @Override public void onCustomAction(String action, Bundle extras) { act(action); }
        });
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kawaii:playback");
        wl.setReferenceCounted(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (a == null || A_INIT.equals(a)) {
            State s = pending;
            pending = null;
            if (s != null) {
                apply(s);
            } else {
                // Harus tetap memanggil startForeground, lalu berhenti.
                startFg(placeholder());
                closeNotif(false);
            }
        } else {
            act(a);
        }
        return START_NOT_STICKY;
    }

    private void act(String a) {
        if (a == null) return;
        switch (a) {
            case A_PLAY:  Bridge.js("window.__nm&&window.__nm('play')"); break;
            case A_PAUSE: Bridge.js("window.__nm&&window.__nm('pause')"); break;
            case A_NEXT:  Bridge.js("window.__nm&&window.__nm('next')"); break;
            case A_PREV:  Bridge.js("window.__nm&&window.__nm('prev')"); break;
            case A_BACK:  Bridge.js("window.__nm&&window.__nm('back10')"); break;
            case A_FWD:   Bridge.js("window.__nm&&window.__nm('fwd10')"); break;
            case A_CLOSE:
                Bridge.js("window.__nm&&window.__nm('stop')");
                closeNotif(true);
                break;
            default: break;
        }
    }

    private void apply(State s) {
        MediaMetadataCompat.Builder m = new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, s.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, s.artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "Kawaii Music")
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, s.dur > 0 ? s.dur : -1);
        if (s.cover != null) {
            m.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, s.cover);
            m.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, s.cover);
        }
        session.setMetadata(m.build());

        long actions = PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS | PlaybackStateCompat.ACTION_SEEK_TO
                | PlaybackStateCompat.ACTION_STOP | PlaybackStateCompat.ACTION_REWIND
                | PlaybackStateCompat.ACTION_FAST_FORWARD;
        PlaybackStateCompat.Builder pb = new PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(s.playing ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED,
                        s.pos, s.playing ? 1f : 0f, SystemClock.elapsedRealtime())
                .addCustomAction(new PlaybackStateCompat.CustomAction.Builder(
                        A_BACK, "Mundur 10 detik", R.drawable.ic_back10).build());
        if (RIGHT_SLOT_IS_FWD10) {
            pb.addCustomAction(new PlaybackStateCompat.CustomAction.Builder(
                    A_FWD, "Maju 10 detik", R.drawable.ic_fwd10).build());
        } else {
            pb.addCustomAction(new PlaybackStateCompat.CustomAction.Builder(
                    A_CLOSE, "Tutup", R.drawable.ic_close).build());
        }
        session.setPlaybackState(pb.build());
        session.setActive(true);

        Notification n = build(s);
        if (!fg) startFg(n); else nm.notify(NOTIF_ID, n);

        if (s.playing) {
            if (!wl.isHeld()) wl.acquire();
        } else if (wl.isHeld()) {
            wl.release();
        }
    }

    private PendingIntent svc(String action, int code) {
        Intent i = new Intent(this, MediaService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent openApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build(State s) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle(s.title)
                .setContentText(s.artist)
                .setContentIntent(openApp())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE);
        if (s.cover != null) b.setLargeIcon(s.cover);

        // Tombol untuk Android < 13 / layar kunci lama: indeks 0..4
        b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_back10, "Mundur 10 detik", svc(A_BACK, 1)).build());
        b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_prev, "Sebelumnya", svc(A_PREV, 2)).build());
        if (s.playing) {
            b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_pause, "Jeda", svc(A_PAUSE, 3)).build());
        } else {
            b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_play, "Putar", svc(A_PLAY, 3)).build());
        }
        b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_next, "Berikutnya", svc(A_NEXT, 4)).build());
        if (RIGHT_SLOT_IS_FWD10) {
            b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_fwd10, "Maju 10 detik", svc(A_FWD, 5)).build());
        } else {
            b.addAction(new NotificationCompat.Action.Builder(R.drawable.ic_close, "Tutup", svc(A_CLOSE, 6)).build());
        }

        b.setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                .setMediaSession(session.getSessionToken())
                .setShowActionsInCompactView(1, 2, 3));
        return b.build();
    }

    private Notification placeholder() {
        return new NotificationCompat.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle("Kawaii Music")
                .setOngoing(true)
                .build();
    }

    private void startFg(Notification n) {
        int type = Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK : 0;
        ServiceCompat.startForeground(this, NOTIF_ID, n, type);
        fg = true;
    }

    /** user=true: ditutup lewat tombol X. */
    void closeNotif(boolean user) {
        if (user) dismissed = true;
        if (wl != null && wl.isHeld()) wl.release();
        if (session != null) session.setActive(false);
        if (fg) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
            fg = false;
        }
        nm.cancel(NOTIF_ID);
        if (inst == this) inst = null;
        stopSelf();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        closeNotif(false);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (wl != null && wl.isHeld()) wl.release();
        if (session != null) {
            session.setActive(false);
            session.release();
        }
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
