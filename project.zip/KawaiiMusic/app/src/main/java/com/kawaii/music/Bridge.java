package com.kawaii.music;

import android.webkit.WebView;

/** Pegangan global ke WebView supaya service bisa menjalankan JS (tombol notifikasi -> pemutar di HTML). */
final class Bridge {
    static volatile WebView web;

    static void js(final String code) {
        final WebView w = web;
        if (w == null) return;
        w.post(new Runnable() {
            @Override public void run() {
                w.evaluateJavascript(code, null);
            }
        });
    }

    private Bridge() {}
}
